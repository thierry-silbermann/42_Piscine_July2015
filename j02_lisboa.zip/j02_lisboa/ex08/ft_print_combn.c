void ft_print_combn(int n)
{

}

/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_comb.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tsilberm <tsilberm@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2015/07/09 18:55:55 by tsilberm          #+#    #+#             */
/*   Updated: 2015/07/09 22:16:25 by tsilberm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_putchar(char c);

void	ft_print_comb(void)
{
	for (int i = 48; i < 58; i++) {	
		for (int j = i + 1; j < 58; j++) { 
			for (int k = j + 1; k < 58; k++)
			{
				ft_putchar(i);
				ft_putchar(j);
				ft_putchar(k);
				if (!(i == 55 && j == 56 && k == 57))
				{
					ft_putchar(',');
					ft_putchar(' ');
				}
			}
		}
	}
}

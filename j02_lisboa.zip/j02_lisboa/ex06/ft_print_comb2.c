/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_comb2.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tsilberm <tsilberm@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2015/07/09 18:55:55 by tsilberm          #+#    #+#             */
/*   Updated: 2015/07/09 22:16:25 by tsilberm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_putchar(char c);

void	ft_print_comb2(void)
{
	for (int i = 48; i < 58; i++) 
	{	
		for (int j = 48; j < 58; j++) 
		{ 
			for (int k = i; k < 58; k++)
			{
				for (int l = 48; l < 58; l++)
				{
					if (i == k && j == l)
					{
						continue;
					}
					if (!(i >= k && j > l))
					{
						ft_putchar(i);
						ft_putchar(j);
						ft_putchar(' ');
						ft_putchar(k);
						ft_putchar(l);
						if (!(i == 57 && j == 56 && k == 57 && l == 57))
						{
							ft_putchar(',');
							ft_putchar(' ');
						}
					}
				}
			}
		}
	}
}


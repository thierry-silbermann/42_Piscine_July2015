void ft_putnbr(int);

int main(void){
	ft_putnbr(42);
}

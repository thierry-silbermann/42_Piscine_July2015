/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_read_from_stdin.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jguthert <jguthert@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2015/07/28 20:28:15 by jguthert          #+#    #+#             */
/*   Updated: 2015/07/30 15:32:26 by tsilberm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "header.h"

#define BUF_SIZE 1024

t_line_base	*ft_get_first_line(t_map *map)
{
	char		*str;
	t_line_base	*line;
	t_line_base *begin_list;
	char        c;
	int         i;
	int         j;
	int         nb_linked_list;
	int         ret;
	
	j = 0;
	i = 0;
	str = malloc(BUF_SIZE);
	nb_linked_list = 0;
	//printf("Get FIRST LINE, fd: %d\n", map->fd);
	ret = read(map->fd, &c, 1);
	while (ret && c != '\n')
	{
		str[i] = c;
		if (i == BUF_SIZE - 1)
		{
		    //printf("Needed extra linked !, value i: %d\n", i);
		    str[i+1] = '\0'; 
			if (nb_linked_list == 0)
			{
				begin_list = ft_create_elem(str);
				line = begin_list;
			}
			else
			{
				line->next = ft_create_elem(str);
				line = line->next;
			}
			i = -1;
			nb_linked_list++;
		}
		i++;
		j++;
		ret = read(map->fd, &c, 1);
	}
	//printf("Nb linked list for first line: %d / rest: %d\n", nb_linked_list, i);
	str[i] = '\0';
	if (nb_linked_list == 0)
		begin_list = ft_create_elem(str);
	else if (i > 0)
		line->next = ft_create_elem(str);
	map->nb_col = j;
	return (begin_list);
}

char		*ft_get_param(char *argv)
{
	int		fd;
	int		i;
	char	c;
	char	*str;
	int		ret;

	i = 0;
	str = malloc(sizeof(char) * 11);
	fd = open(argv, O_RDONLY);
	printf("FD: %d\n", fd);
	if (fd == -1)
		return (NULL);
	ret = read (fd, &c, 1);
	while (ret && i < 10 && c != '\n')
	{
		str[i] = c;
		i++;
		ret = read (fd, &c, 1);
	}
	str[i] = '\0';
	return (str);
}
/*
**	A verifier aue O_TRUNC supprime bien le contenu du fichier precedent
*/
int			ft_read_from_stdin()
{
	int		fd;
	char	*buffer;
	int		ret;

	buffer = (char*)malloc(sizeof(char) * 4096);
	if (buffer == NULL)
	{
		printf("FAIL 1");
		return (0);
	}
	fd = open ("my_map", O_WRONLY | O_CREAT | O_TRUNC | O_APPEND, 0666);
	if (fd == -1)
	{
		printf("FAIL 2");
		return (0);
	}
	while ((ret = read(0, buffer, sizeof(buffer) - 1)))
	{
		buffer[ret] = '\0';
		write(fd, buffer, ft_strlen(buffer));
	}
	if (close(fd) == -1)
	if (buffer == NULL)
	{
		printf("FAIL 3");
		return (0);
	}
	free (buffer);
	return (1);
}

/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   linked_list.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tsilberm <tsilberm@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2015/07/28 21:34:55 by tsilberm          #+#    #+#             */
/*   Updated: 2015/07/30 15:28:37 by tsilberm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "header.h"
#define BUF_SIZE 1024

t_line_base	*ft_create_elem(char *line)
{
	t_line_base *new_elem;

	new_elem = malloc(sizeof(t_line_base));
	if (new_elem)
	{
		new_elem->line = line;
		new_elem->next = NULL;
	}
	return (new_elem);
}

t_line_base		*get_next_line(int fd, int size_col)
{
	int			nb_linked_list;
	int			nb_rest;
	t_line_base	*begin_list;
	t_line_base	*ptr_list;
	int			i;
	int			ret;
	char		*buf1;
	char		*buf2;
	char		*buf;

	i = 0;
	nb_linked_list = (size_col / (BUF_SIZE - 1)) + 1;
	nb_rest = size_col - (BUF_SIZE - 1) * (size_col / (BUF_SIZE - 1)) + 1;
	//printf("nb_l: %d / nb_rest: %d\n", nb_linked_list, nb_rest);
	buf1 = malloc(sizeof(char) * BUF_SIZE);
	buf2 = malloc(sizeof(char) * nb_rest);
	while (i < nb_linked_list)
	{
		if ((i + 1 == nb_linked_list) && (nb_rest > 0))
		{
			ret = read(fd, buf2, nb_rest);
			buf = buf2;
		}
		else
		{
			ret = read(fd, buf1, BUF_SIZE);
			buf = buf1;
		}
		if (ret == 0)
		{
			begin_list = 0;
			break ;
		}
		buf[ret] = '\0';
		if (i == 0)
		{
			ptr_list = ft_create_elem(buf);
			begin_list = ptr_list;
		}   
		else
		{
			ptr_list->next = ft_create_elem(buf);
			ptr_list = ptr_list->next;
		}
		i++;
	}
	free(buf1);
	free(buf2);
	return (begin_list);
}

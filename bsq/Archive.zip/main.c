/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tsilberm <tsilberm@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2015/07/27 14:03:18 by tsilberm          #+#    #+#             */
/*   Updated: 2015/07/30 15:36:11 by tsilberm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "header.h"
#define BUF_SIZE 1 + 1

void	solve_file(t_map *map, char *filename)
{
	t_solution		*best_sqr;
	t_line_base		*f_line;

	best_sqr = initialize_solution();
	f_line = ft_get_first_line(map);
	printf("First_line: '%s' / nb_col: %d\n", f_line->line , map->nb_col);
	best_sqr = search_solution(best_sqr, f_line, map);
	printf("x: %d/ y: %d/ max: %d\n", best_sqr->x, best_sqr->y, best_sqr->max);
	close(map->fd);
	//printf("%s\n", filename);
	ft_print_solution(best_sqr, filename, map);
}

void	read_from_args(char *argv)
{
	t_map	*map;
	char	*first_line;
	char	*filename;

	//Si probleme du filename, faire un malloc
	filename = ft_strdup(argv);
	if (!(first_line = ft_get_param(filename)))
		return ;
	if (!(map = ft_init_par_map(first_line)))
		return ;
	map->fd = 3;
	solve_file(map, filename);
}

int		main(int argc, char **argv)
{
	int		i;

	i = 1;
	if (argc > 1)
	{
		while (i < argc)
		{
		    printf("Nb argc: %d\n", argc);
			read_from_args(argv[i]);
			i++;
		}
	}
	else if (ft_read_from_stdin())
		read_from_args("my_map");
	else
		ft_puterror("map error my map\n");
	return (0);
}

/*
 **VERIFIER SI MAP EST NULL
 */
